@extends('layouts.app')

@section('title', 'Certificados maestro/colaborador')

@section('page_title', 'Certificados maestro/colaborador')

@section('page_subtitle')
Generación de certificados para profesores y colaboradores del concurso Bebras Cuba.
@endsection

@section('content')

<div class="card">
    <p>
        <strong>Total:</strong> {{ count($usuarios) }}
    </p>
</div>

<div class="card">
    <table>
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Correo</th>
                <th>Rol</th>
                <th>Acciones</th>
            </tr>
        </thead>

        <tbody>
            @forelse($usuarios as $usuario)
            <tr>
                <td>{{ $usuario->nombre }} {{ $usuario->apellidos }}</td>
                <td>{{ $usuario->correo }}</td>
                <td>
                    <span class="badge badge-ok">
                        {{ $usuario->rol }}
                    </span>
                </td>
                <td>
                    <a class="btn btn-dark" href="/coordinador/certificados-colaboradores/generar/{{ $usuario->id }}" target="_blank">
                        Generar certificado
                    </a>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="4">No existen profesores o colaboradores registrados.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>

@endsection